import { defineStore } from "pinia";

export const useQuizStore = defineStore("quiz", {
    state: () => ({
        questions: [], // The randomly selected questions
        allQuestions: [], // The full pool of questions
        currentQuestionIndex: null, // Index of the current question
        selectedAnswers: {}, // User-selected answers
        results: null, // Results after the quiz ends
        pickedQuestions: 2, // Default number of picked questions
        approvalScore: 1, // Minimum score to pass
        residentApprovalScore: 2, // Minimum score for resident approval
    }),
    getters: {
        correctAnswersCount(state) {
            return state.results
                ? state.results.filter((result) => result.isCorrect).length
                : 0;
        },
        isApproved(state) {
            return state.correctAnswersCount >= state.approvalScore;
        },
        hasResidentApproval(state) {
            return state.correctAnswersCount >= state.residentApprovalScore;
        },
    },
    actions: {
        async loadQuestions() {
            try {
                const response = await fetch("/src/questions.json");
                const data = await response.json();

                this.allQuestions = data; // Store the full pool of questions
                const selectedQuestions = this.getRandomSubset(this.allQuestions, this.pickedQuestions);

                // Shuffle choices and adjust the `correct` index for each question
                this.questions = selectedQuestions.map((question) => {
                    // Shuffle the choices array
                    const shuffledChoices = this.shuffleArray([...question.choices]);
                    // Find the new index of the correct answer
                    const originalCorrectChoice = question.choices[question.correct - 1]; // 1-based to 0-based
                    const newCorrectIndex = shuffledChoices.indexOf(originalCorrectChoice); // New 0-based index

                    return {
                        ...question,
                        choices: shuffledChoices,
                        correct: newCorrectIndex, // Update correct index for the shuffled array
                    };
                });

                this.currentQuestionIndex = 0; // Start with the first question
            } catch (error) {
                console.error("Failed to load questions:", error);
            }
        },
        shuffleArray(array) {
            // Fisher-Yates shuffle algorithm
            for (let i = array.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [array[i], array[j]] = [array[j], array[i]];
            }
            return array;
        },
        getRandomSubset(array, count) {
            const shuffled = array.sort(() => Math.random() - 0.5); // Shuffle the array
            return shuffled.slice(0, count); // Take the first `count` items
        },
        selectAnswer(answerIndex) {
            const currentQuestion = this.questions[this.currentQuestionIndex];
            if (currentQuestion) {
                this.selectedAnswers[currentQuestion.id] = answerIndex;
                this.nextQuestion();
            }
        },
        nextQuestion() {
            if (this.currentQuestionIndex < this.questions.length - 1) {
                this.currentQuestionIndex++;
            } else {
                this.calculateResults();
            }
        },
        calculateResults() {
            this.results = this.questions.map((question) => {
                const userAnswer = this.selectedAnswers[question.id];
                const isCorrect = userAnswer === question.correct; // Correct index is now aligned with shuffled choices
                return { question, userAnswer, isCorrect };
            });
        },
        resetQuiz() {
            this.questions = [];
            this.currentQuestionIndex = null;
            this.selectedAnswers = {};
            this.results = null;
            this.questions = this.getRandomSubset(this.allQuestions, this.pickedQuestions); // Pick a new random set
        },
    },
});
